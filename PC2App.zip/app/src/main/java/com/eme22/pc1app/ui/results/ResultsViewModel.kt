package com.eme22.pc1app.ui.results

import androidx.lifecycle.ViewModel

class ResultsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}